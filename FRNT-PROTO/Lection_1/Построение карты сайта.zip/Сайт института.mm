
<map version="0.9.0">
    <node TEXT="Сайт института" FOLDED="false">
        <edge COLOR="#b4b4b4" />
        <font NAME="Helvetica" SIZE="10" />
        <node TEXT="Международная деятельность" FOLDED="false" POSITION="left">
            <edge COLOR="#9ed56b" />
            <font NAME="Helvetica" SIZE="10" />
            <node TEXT="Международные образовательные программы" FOLDED="false">
                <edge COLOR="#abd46f" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Иностранным студентам" FOLDED="false">
                <edge COLOR="#abd566" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
        </node>
        <node TEXT="Контакты" FOLDED="false" POSITION="right">
            <edge COLOR="#ebd95f" />
            <font NAME="Helvetica" SIZE="10" />
        </node>
        <node TEXT="Об институте" FOLDED="false" POSITION="left">
            <edge COLOR="#7aa3e5" />
            <font NAME="Helvetica" SIZE="10" />
            <node TEXT="Приветственное слово директора" FOLDED="false">
                <edge COLOR="#7d97e7" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Персоналии" FOLDED="false">
                <edge COLOR="#7d9be5" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="История (миссия)" FOLDED="false">
                <edge COLOR="#76a8e4" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Кафедры" FOLDED="false">
                <edge COLOR="#76abe6" />
                <font NAME="Helvetica" SIZE="10" />
                <node TEXT="Описание кафедры [#](#6724e7)" FOLDED="false">
                    <edge COLOR="#78c2e5" />
                    <font NAME="Helvetica" SIZE="10" />
                </node>
            </node>
        </node>
        <node TEXT="Выпускникам" FOLDED="false" POSITION="right">
            <edge COLOR="#e68782" />
            <font NAME="Helvetica" SIZE="10" />
        </node>
        <node TEXT="Направления подготовки" FOLDED="false" POSITION="left">
            <edge COLOR="#7aa3e5" />
            <font NAME="Helvetica" SIZE="10" />
        </node>
        <node TEXT="Студентам" FOLDED="false" POSITION="right">
            <edge COLOR="#9ed56b" />
            <font NAME="Helvetica" SIZE="10" />
            <node TEXT="Практики и стажировки" FOLDED="false">
                <edge COLOR="#acd66d" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Документы и учебные материалы" FOLDED="false">
                <edge COLOR="#8ad66b" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Общая информация" FOLDED="false">
                <edge COLOR="#a8d368" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Расписание(ссылка)" FOLDED="false">
                <edge COLOR="#b0d46d" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Расписание преподавателей (ссылка)" FOLDED="false">
                <edge COLOR="#89d36e" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
        </node>
        <node TEXT="Наука" FOLDED="false" POSITION="left">
            <edge COLOR="#67d7c4" />
            <font NAME="Helvetica" SIZE="10" />
            <node TEXT="Конференции и семинары" FOLDED="false">
                <edge COLOR="#6ed7cd" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Гранты" FOLDED="false">
                <edge COLOR="#69d8b0" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Общая информация" FOLDED="false">
                <edge COLOR="#69d1d6" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Публикации" FOLDED="false">
                <edge COLOR="#66d7cf" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Научные направления" FOLDED="false">
                <edge COLOR="#6dd6d6" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Достижения [#](#846137)" FOLDED="false">
                <edge COLOR="#6ddad7" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Лаборатории" FOLDED="false">
                <edge COLOR="#6ed6d7" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
        </node>
        <node TEXT="Аспирантам" FOLDED="false" POSITION="right">
            <edge COLOR="#ebd95f" />
            <font NAME="Helvetica" SIZE="10" />
            <node TEXT="Список специальностей" FOLDED="false">
                <edge COLOR="#ead85d" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Данные по аспирантам (doc)" FOLDED="false">
                <edge COLOR="#e8e05d" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Условия приема" FOLDED="false">
                <edge COLOR="#edc162" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
        </node>
        <node TEXT="Медиа" FOLDED="false" POSITION="left">
            <edge COLOR="#e68782" />
            <font NAME="Helvetica" SIZE="10" />
            <node TEXT="Новости" FOLDED="false">
                <edge COLOR="#e48f83" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Видеоархив" FOLDED="false">
                <edge COLOR="#e7908a" />
                <font NAME="Helvetica" SIZE="10" />
                <node TEXT="Видео" FOLDED="false">
                    <edge COLOR="#e99593" />
                    <font NAME="Helvetica" SIZE="10" />
                </node>
            </node>
            <node TEXT="Фотоальбомы" FOLDED="false">
                <edge COLOR="#e69987" />
                <font NAME="Helvetica" SIZE="10" />
                <node TEXT="Фотоальбом" FOLDED="false">
                    <edge COLOR="#e5a989" />
                    <font NAME="Helvetica" SIZE="10" />
                </node>
            </node>
        </node>
        <node TEXT="Партнерам" FOLDED="false" POSITION="right">
            <edge COLOR="#efa670" />
            <font NAME="Helvetica" SIZE="10" />
            <node TEXT="Список партнеров(st)" FOLDED="false">
                <edge COLOR="#ef9b6d" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Варианты сотрудничества" FOLDED="false">
                <edge COLOR="#f0b276" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
        </node>
        <node TEXT="Абитуриентам" FOLDED="false" POSITION="right">
            <edge COLOR="#988ee3" />
            <font NAME="Helvetica" SIZE="10" />
            <node TEXT="Актуальная информация" FOLDED="false">
                <edge COLOR="#9193e3" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Направления подготовки [#](#6724e7)" FOLDED="false">
                <edge COLOR="#ab94e6" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Международные образовательные программы [#](#9c8dc0)" FOLDED="false">
                <edge COLOR="#9c84e2" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
            <node TEXT="Подготовительные курсы" FOLDED="false">
                <edge COLOR="#8985e1" />
                <font NAME="Helvetica" SIZE="10" />
            </node>
        </node>
        <node TEXT="Личный кабинет" FOLDED="false" POSITION="left">
            <edge COLOR="#e096e9" />
            <font NAME="Helvetica" SIZE="10" />
        </node>
    </node>
</map>